create database Bookstore;
use Bookstore;
create table books( Category varchar(20), Name varchar(20), Qty int, Rate int);
Insert into books values('Fiction','Gravity',200,450);
Insert into books values('History','WW2',100,350);
Insert into books values('Fiction','DaVinciCode',100,350);
Insert into books values('Science','Space Travel',200,450);
Insert into books values('Fiction','Interstellar',100,450);
exit;