setup_ec2.sh: Automates LAMP stack installation and application deployment.

